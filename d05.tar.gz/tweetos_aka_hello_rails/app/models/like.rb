class Like < ActiveRecord::Base


end
