class Cuicui < ActiveRecord::Base

  # scope :top, lambda { implementez ici }

  def fame

  end

end
