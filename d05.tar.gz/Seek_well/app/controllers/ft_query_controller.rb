
class FtQueryController < ApplicationController
  def index
   
  end

  def create_db
  
  end

  def create_table
  
  end

  def drop_table
  
  end

  def start_race
   
  end

  def insert_time_stamp
  
  end

  def delete_last

  end

  def destroy_all
   
  end

  def all_by_name
 
  end

  def all_by_race
   
  end

  def update_time_stamp
  
  end

  private


end
