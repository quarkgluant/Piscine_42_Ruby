# Taillste

```ruby
gem 'taillste'
```

## Usage

Once you are in gem's root folder run:
```shell
bundle exec rake
```
## License

The gem is available as open source under the terms of the [MIT License](http://opensource.org/licenses/MIT).
